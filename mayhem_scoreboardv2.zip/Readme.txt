Launch obs.exe with '--disable-web-security --user-data-dir="/tmp/chrome_dev"' argument to disable CORS in fetching Challonge API

Add "mayhem-panel.html" as a custom browser with "http://absolute/" in front of the URL.
E.g. http://absolute/C:\Users\username\Downloads\mayhem_scoreboard\mayhem-panel.html