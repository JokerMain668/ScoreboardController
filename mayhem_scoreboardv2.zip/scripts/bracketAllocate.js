function allocateBracket() {
    const bracketID = {
        'Street Fighter 6': {
            id: '985871',
            challonge: false
        },
        'Tekken 7': {
            id: '985872',
            challonge: false
        },
        'Guilty Gear -Strive-': {
            id: '985873',
            challonge: false
        },
        'Mortal Kombat 1': {
            id: '985869',
            challonge: false
        },
        'King of Fighters XV': {
            id: '985874',
            challonge: false
        },
        'BlazBlue: Central Fiction': {
            id: '985879',
            challonge: false
        },
        'Ultimate Marvel vs. Capcom 3': {
            id: '990575',
            challonge: false
        },
        'Guilty Guilty Gear Xrd REV 2': {
            id: '985882',
            challonge: false
        },
        'Guilty Gear XX Accent Core Plus R': {
            id: '1011847',
            challonge: false
        },
        'Skullgirls: 2nd Encore': {
            id: '985883',
            challonge: false
        },
        'Dragon Ball FighterZ': {
            id: '985886',
            challonge: false
        },
        'Samurai Shodown': {
            id: '985884',
            challonge: false
        },
        'Pokkén Tournament DX': {
            id: '985881',
            challonge: false
        },
        'Under Night In-Birth Exe:Late[cl-r]': {
            id: '985887',
            challonge: false
        },
        'Melty Blood: Type Lumina': {
            id: '1011846',
            challonge: false
        },
        'Killer Instinct': {
            id: '985885',
            challonge: false
        },
        'Virtua Fighter 5: Ultimate Showdown': {
            id: '985888',
            challonge: false
        },
        "The King of Fighters '98": {
            id: '13706329',
            challonge: true
        },
        'Taiko no Tatsujin': {
            id: 'a3szdm60',
            challonge: true
        },
        'Street Fighter 3: Third Strike': {
            id: '13686326',
            challonge: true
        },
        'DNF Duel': {
            id: '13709444',
            challonge: true
        },
        'Kill la Kill: If': {
            id: '13689793',
            challonge: true
        },
        'Armored Core 6': {
            id: 'qfr1umo2',
            challonge: true
        },
        'The King of Fighters XIII': {
            id: '13706340',
            challonge: true   
        },
        'Melty Blood: Actress Again: Current Code': {
            id: '13686443',
            challonge: true
        },
        "Them's Fightin' Herds": {
            id: '13686058',
            challonge: true
        },
        'Vampire Savior': {
            id: '13686060',
            challonge: true
        },
        'Advanced V.G. 2': {
            id: '13686047',
            challonge: true
        },
        'Touhou 12.3 Hisoutensoku': {
            id: '13707120',
            challonge: true
        },
        'The King of Fighters 2002': {
            id: '13706337',
            challonge: true
        },
        'MOBILE SUIT GUNDAM EXTREME VS MAXIBOOST ON': {
            id: '13707053',
            challonge: true
        },
        'Kamen Rider: Super Climax Heroes': {
            id: '13686411',
            challonge: true
        },
        'Persona 4 Arena Ultimax': {
            id: '13707528',
            challonge: true
        },
        'Mario Kart 8: 2v2': {
            id: 'cuj72h99',
            challonge: true
        },
        'Just Dance 2022': {
            id: '6qykbtv6',
            challonge: true
        },
        'Divekick': {
            id: '13686302',
            challonge: true
        }
    }
    var game = $('#game option:selected').text();
    $('#bracketChecked').prop('checked', bracketID[game]['challonge']);
    if (bracketID[game]['challonge']) $('#challongeID').val(bracketID[game]['id']);
    else $('#startggID').val(bracketID[game]['id']);
    setPlayerList();
}
